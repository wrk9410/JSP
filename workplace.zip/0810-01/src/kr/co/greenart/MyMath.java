package kr.co.greenart;

public class MyMath {
	public int sum(int left, int right) {
		return left + right;
	}
}
